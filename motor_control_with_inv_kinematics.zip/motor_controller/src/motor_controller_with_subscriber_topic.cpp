#include "ros/ros.h"
#include "roboclaw/RoboclawMotorVelocity.h"
#include "roboclaw/RoboclawEncoderSteps.h"
#include "motor_controller/position.h"
#include <sstream>
#include <iostream>
using namespace std;
float Kp1=1,ki1=0.0000001,kd1=0.1,prev_e1=0,max_speed=30000,total_error_1=0;
float Kp2=1,ki2=0.0000001,kd2=0.1,prev_e2=0,max_speed_2=30000,total_error_2=0;

ros::Publisher velocity_publisher;
ros::Subscriber pose_subscriber;
ros::Subscriber position_subscriber;

ros::Publisher velocity_publisher_1;
ros::Subscriber pose_subscriber_1;

roboclaw::RoboclawEncoderSteps pose;
roboclaw::RoboclawEncoderSteps pose_1;
motor_controller::position position;


void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message);
void positionCallback(const motor_controller::position::ConstPtr& position_message);
void PIDcontroller(float goal1,float goal2);


void pose_1Callback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message);





int main(int argc, char **argv)
{ros::init(argc,argv,"motor_controller");
ros::NodeHandle n;
ros::Rate rate(10);

velocity_publisher=n.advertise<roboclaw::RoboclawMotorVelocity>("/motor_cmd_vel",10);
pose_subscriber=n.subscribe("/motor_enc",10,&poseCallback);
position_subscriber=n.subscribe("/position",10,&positionCallback);


velocity_publisher_1=n.advertise<roboclaw::RoboclawMotorVelocity>("/motor_cmd_vel_1",10);
pose_subscriber_1=n.subscribe("/motor_enc_1",10,&pose_1Callback);



cout<<position.position_1<<"    "<<position.position_2<<endl;
while(ros::ok())
{//cout<<"Start"<<endl;
PIDcontroller(position.position_1,position.position_2);
//cout<<"End"<<endl;

roboclaw::RoboclawMotorVelocity vel_msg;
vel_msg.index=0;
vel_msg.mot1_vel_sps=0;
velocity_publisher.publish(vel_msg);


roboclaw::RoboclawMotorVelocity vel_msg_1;
vel_msg_1.index=0;
vel_msg_1.mot1_vel_sps=0;
velocity_publisher_1.publish(vel_msg_1);


ros::spinOnce();}
//cout<<pose.mot1_enc_steps<<endl;

}


void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message){
	pose.index=pose_message->index;
	pose.mot1_enc_steps=pose_message->mot1_enc_steps;
	pose.mot2_enc_steps=pose_message->mot2_enc_steps;
	//PIDcontroller(position.position_1,position.position_2);
	

}


void pose_1Callback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message){
	pose_1.index=pose_message->index;
	pose_1.mot1_enc_steps=pose_message->mot1_enc_steps;
	pose_1.mot2_enc_steps=pose_message->mot2_enc_steps;
	//PIDcontroller(position.position_1,position.position_2);
	

}

void positionCallback(const motor_controller::position::ConstPtr& position_message){
	position.position_1=position_message->position_1;
	position.position_2=position_message->position_2;
	position.position_3=position_message->position_3;
	PIDcontroller(position.position_1,position.position_2);
	

}
void PIDcontroller(float goal, float goal1)
{roboclaw::RoboclawMotorVelocity vel_msg_; 
roboclaw::RoboclawMotorVelocity vel_msg_1;
vel_msg_.index=0;
vel_msg_1.index=0;
while(abs(abs(goal)-float(pose.mot1_enc_steps))>50.0        ||    abs(abs(goal1)-float(pose_1.mot1_enc_steps))>50.0)
	{cout<<abs(goal)-abs(float(pose.mot1_enc_steps))<<"    "<<abs(goal1)-abs(float(pose_1.mot1_enc_steps))<<endl;
	float e=goal-float(pose.mot1_enc_steps);
	float e1=goal1-float(pose_1.mot1_enc_steps);
	
        int speed=Kp1*e+ki1*(total_error_1)+kd1*(e-prev_e1);
	int speed1=Kp2*e1+ki2*(total_error_2)+kd2*(e1-prev_e2);
	

	if (speed>max_speed)
		speed=max_speed;
	else if(speed<-max_speed)
		speed=-max_speed;

	if (speed1>max_speed)
		speed1=max_speed;
	else if(speed1<-max_speed)
		speed1=-max_speed;

	vel_msg_.mot1_vel_sps=1*speed;
	vel_msg_1.mot1_vel_sps=1*speed1;
	

	velocity_publisher.publish(vel_msg_);
	velocity_publisher_1.publish(vel_msg_1);	


	ros::spinOnce();
	//loop_rate.sleep();
	prev_e1=e;
	total_error_1=total_error_1+e;

	prev_e2=e1;
	total_error_2=total_error_2+e1;
	//ros::Duration(0.1).sleep();
	}
vel_msg_.mot1_vel_sps=0;
velocity_publisher.publish(vel_msg_);

vel_msg_1.mot1_vel_sps=0;
velocity_publisher_1.publish(vel_msg_1);
cout<<"loop ended"<<endl;
}




