#include "ros/ros.h"
#include "roboclaw/RoboclawMotorVelocity.h"
#include "roboclaw/RoboclawEncoderSteps.h"
#include "motor_controller/position.h"
#include "std_msgs/String.h"
#include "geometry_msgs/Pose2D.h"
#include <sstream>
#include <iostream>
#include "sensor_msgs/Joy.h"
using namespace std;
float Kp1=1.5,  ki1=0.000000,  kd1=1,prev_e1=0,max_speed=1500,total_error_1=0;
float Kp2=1.5,  ki2=0.000000, kd2=1,prev_e2=0,max_speed_2=1500,total_error_2=0;
float Kp3=1.5,  ki3=0.000000,  kd3=1,prev_e3=0,max_speed_3=1500,total_error_3=0;

ros::Publisher velocity_publisher;
ros::Subscriber pose_subscriber;
ros::Subscriber position_subscriber;

ros::Publisher velocity_publisher_1;
ros::Subscriber pose_subscriber_1;
ros::Publisher DonePublisher;
std_msgs::String DoneString;
ros::Publisher ForwardKinematicsPositionPublisher;


roboclaw::RoboclawEncoderSteps pose;
roboclaw::RoboclawEncoderSteps pose_1;
motor_controller::position position;
float full_speed=1500;


void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message);
void positionCallback(const motor_controller::position::ConstPtr& position_message);
void PIDcontroller(float goal1,float goal2,float goal3);
void ForwardKinematics();


void pose_1Callback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message);





int main(int argc, char **argv)
{ros::init(argc,argv,"motor_controller");
ros::NodeHandle n;
ros::Rate rate(10);

velocity_publisher=n.advertise<roboclaw::RoboclawMotorVelocity>("/motor_cmd_vel",10);
ForwardKinematicsPositionPublisher=n.advertise<geometry_msgs::Pose2D>("/robot_odom_position",10);
pose_subscriber=n.subscribe("/motor_enc",100,&poseCallback);
position_subscriber=n.subscribe("/position",100,&positionCallback);


velocity_publisher_1=n.advertise<roboclaw::RoboclawMotorVelocity>("/motor_cmd_vel_1",10);
pose_subscriber_1=n.subscribe("/motor_enc_1",10,&pose_1Callback);
DonePublisher=n.advertise<std_msgs::String>("/DoneTopic",10);


ros::spinOnce();
//cout<<position.position_1<<"    "<<position.position_2<<"  "<<position.position_3<<endl;
while(ros::ok())
{//cout<<"Start"<<endl;
PIDcontroller(position.position_1,position.position_2,position.position_3);
//cout<<"End"<<endl;

ForwardKinematics();





roboclaw::RoboclawMotorVelocity vel_msg;
vel_msg.index=0;
vel_msg.mot1_vel_sps=0;
vel_msg.mot2_vel_sps=0;                                               //To stop the motor when pid successful
velocity_publisher.publish(vel_msg);


roboclaw::RoboclawMotorVelocity vel_msg_1;
vel_msg_1.index=0;							//To stop the motor when pid successful
vel_msg_1.mot2_vel_sps=0;
velocity_publisher_1.publish(vel_msg_1);


ros::spinOnce();}
//cout<<pose.mot1_enc_steps<<endl;

}


void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message){
	pose.index=pose_message->index;
	pose.mot1_enc_steps=pose_message->mot1_enc_steps;
	pose.mot2_enc_steps=pose_message->mot2_enc_steps;
	//PIDcontroller(position.position_1,position.position_2);
	

}


void pose_1Callback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message){
	pose_1.index=pose_message->index;
	pose_1.mot1_enc_steps=pose_message->mot1_enc_steps;
	pose_1.mot2_enc_steps=pose_message->mot2_enc_steps;
	//PIDcontroller(position.position_1,position.position_2);
	

}

void positionCallback(const motor_controller::position::ConstPtr& position_message){
	position.position_1=position_message->position_1;
	position.position_2=-position_message->position_2;
	position.position_3=-position_message->position_3;
	//cout<<position.position_1<<"  "<<position.position_2<<"  "<<position.position_3<<endl;
	total_error_1=0;
	total_error_2=0;
	total_error_3=0;	
	//PIDcontroller(position.position_1,position.position_2);
	
	

}
void PIDcontroller(float goal, float goal1,float goal2)
{


roboclaw::RoboclawMotorVelocity vel_msg_; 
roboclaw::RoboclawMotorVelocity vel_msg_1;
vel_msg_.index=0;
vel_msg_1.index=0;
goal=position.position_1;
goal1=position.position_2;
goal2=position.position_3;
float e_current=goal-float(pose.mot1_enc_steps);
float e_current_1=goal1-float(pose_1.mot2_enc_steps);
float e_current_2=goal2-float(pose.mot2_enc_steps);


while((abs((goal)-(float(pose.mot1_enc_steps)))>10.0        ||    abs((goal1)-(float(pose_1.mot2_enc_steps)))>10.0    ||   abs((goal2)-(float(pose.mot2_enc_steps)))>10.0)  &&   ros::ok() )
	{
	ForwardKinematics();
	if(abs((goal)-(float(pose.mot1_enc_steps)))>500     &&   abs((goal1)-(float(pose_1.mot2_enc_steps)))>500    &&   abs((goal2)-(float(pose.mot2_enc_steps)))>500)
		{	ros::spinOnce();
			goal=position.position_1;
			goal1=position.position_2;
			goal2=position.position_3;
			e_current=goal-float(pose.mot1_enc_steps);
			e_current_1=goal1-float(pose_1.mot2_enc_steps);
			e_current_2=goal2-float(pose.mot2_enc_steps);
			int max_speed_=abs(e_current_1)*3.5;
			if (max_speed_>full_speed)
				max_speed_=full_speed;
			int speed=0;
			int speed1=0;
			int speed2=0;
			if (abs(e_current) >= abs(e_current_1)   and  abs(e_current) >= abs(e_current_2)  )
				{speed=max_speed_*e_current/abs(e_current);
				speed1=max_speed_*abs(e_current_1/e_current)*e_current_1/abs(e_current_1);
				speed2=max_speed_*abs(e_current_2/e_current)*e_current_2/abs(e_current_2);

				}

			else if (abs(e_current_1) >= abs(e_current_2)   and  abs(e_current_1) >= abs(e_current))
				{speed1=max_speed_*e_current_1/abs(e_current_1);
				 speed=max_speed_*abs(e_current/e_current_1)*e_current/abs(e_current);
				 speed2=max_speed_*abs(e_current_2/e_current_1)*e_current_2/abs(e_current_2);
				}

			else if (abs(e_current_2) >= abs(e_current)   and  abs(e_current_2) >= abs(e_current_1))
				{speed2=max_speed_*e_current_2/abs(e_current_2);
				 speed=max_speed_*abs(e_current/e_current_2)*e_current/abs(e_current);
				 speed1=max_speed_*abs(e_current_1/e_current_2)*e_current_1/abs(e_current_1);
				}			

			//cout<<"SpeedLoop"<<"   "<<speed<<"  "<<speed1<<"  "<<speed2<<endl;
			DoneString.data="SpeedLoop";
			DonePublisher.publish(DoneString);
			vel_msg_.mot1_vel_sps=int(1*speed);
			vel_msg_1.mot2_vel_sps=int(1*speed1);
			vel_msg_.mot2_vel_sps=int(1*speed2);
		
			velocity_publisher.publish(vel_msg_);
			velocity_publisher_1.publish(vel_msg_1);

			
		}
	
		else
	{
	
		goal=position.position_1;
		goal1=position.position_2;
		goal2=position.position_3;	
		float e=goal-float(pose.mot1_enc_steps);
		float e1=goal1-float(pose_1.mot2_enc_steps);
		float e2=goal2-float(pose.mot2_enc_steps);
	    float speed=Kp1*e+ki1*(total_error_1)+kd1*(e-prev_e1);
		float speed1=Kp2*e1+ki2*(total_error_2)+kd2*(e1-prev_e2);
		float speed2=Kp3*e2+ki3*(total_error_3)+kd3*(e2-prev_e3);

		if (speed>max_speed)
			speed=max_speed;
		else if(speed<-max_speed)
			speed=-max_speed;

		if (speed1>max_speed)
			speed1=max_speed;
		else if(speed1<-max_speed)
			speed1=-max_speed;

		if (speed2>max_speed)
			speed2=max_speed;
		else if(speed2<-max_speed)
			speed2=-max_speed;

		int temp1=00,temp2=00;
		// if (e<0)
		// 	temp1=-temp1;
		// if (e2<0)
		// 	temp2=-temp2;
		
	 //   if (speed>3000    &&   speed1>3000      &&    speed2>3000)
	 //   		{speed=speed*(abs(e_current)/(abs(e_current)+abs(e_current_1)+abs(e_current_2)));
	 //   		speed1=speed1*(abs(e_current_1)/(abs(e_current)+abs(e_current_1)+abs(e_current_2)));
	 //   		speed2=speed2*(abs(e_current_2)/(abs(e_current)+abs(e_current_1)+abs(e_current_2)));}

		vel_msg_.mot1_vel_sps=int(speed);
		vel_msg_1.mot2_vel_sps=int(speed1);
		vel_msg_.mot2_vel_sps=int(speed2);
		//vel_msg_1.mot1_vel_sps=1*speed;                    ///Just for checking


		
		//cout<<speed<<"   "<<speed1<<"   "<<speed2<<endl;
		//cout<<abs(goal)-abs(float(pose.mot1_enc_steps))<<"    "<<abs(goal1)-abs(float(pose_1.mot2_enc_steps))<<"    "<<abs(goal2)-abs(float(pose.mot2_enc_steps))<<" speeds    "<<temp1+speed<<"   "<<speed1<<"   "<<speed2+temp2<<endl;
		
		velocity_publisher.publish(vel_msg_);
		velocity_publisher_1.publish(vel_msg_1);	


		ros::spinOnce();
		//loop_rate.sleep();
		prev_e1=e;
		total_error_1=total_error_1+e;

		prev_e2=e1;
		total_error_2=total_error_2+e1;

		prev_e3=e2;
		total_error_3=total_error_3+e2;
		}
	//ros::Duration(0.1).sleep();
	}

vel_msg_.mot1_vel_sps=0;
vel_msg_.mot2_vel_sps=0;
velocity_publisher.publish(vel_msg_);

vel_msg_1.mot2_vel_sps=0;
velocity_publisher_1.publish(vel_msg_1);



//cout<<"DONE"<<endl;
DoneString.data="Done";
DonePublisher.publish(DoneString);

//ros::spinOnce();
//cout<<"loop ended"<<endl;
//cout<<"hi"<<endl;

}



void ForwardKinematics(){
	ros::spinOnce();
	auto w1=float(pose.mot1_enc_steps);
	auto w2=-float(pose_1.mot2_enc_steps);
	auto w3=-float(pose.mot2_enc_steps);

	/*auto r=101.6;auto R=300;
	auto m=180.0*2400.0*r/360.0/3.14159;m=1/m;
	float cos30=sqrt(3)/2;

	geometry_msgs::Pose2D temp;
	temp.x=((-w1/2.0)+(-w2/2.0)+(w3))//m*((2.00/3.0*w1)-(1.0/3.0*w2)-(1.0/3.0*w3));
	temp.y=m*((0*w1)-(250.0/433.0*w2)+(250.0/433.0*w3));
	temp.theta=m/R/3*(-w1-w2-w3);*/



	geometry_msgs::Pose2D temp;
	temp.x=((4503599627370496.0*w1)/25397388702750567.0) - ((1501205072273259.0*w2)/16931592468500378.0) - ((6004778717228287.0*w3)/67726369874001512.0);
    temp.y=(w1/67726369874001512.0) - ((5196483093625199.0*w2)/33863184937000756.0) + ((1299120773406300.0*w3)/8465796234250189.0);
 	temp.theta=(- (562949953421312.0*w1)/1904804152706292525.0) - ((5124113313359391.0*w2)/17337950687744387072.0) - ((160127432459421.0*w3)/541810958992012096.0);
 	temp.theta=temp.theta*180.0/3.14159;

	cout<<temp.x<<"  "<<temp.y<<"  "<<temp.theta<<endl;
	ForwardKinematicsPositionPublisher.publish(temp);

}
