#include "ros/ros.h"
#include "roboclaw/RoboclawMotorVelocity.h"
#include "roboclaw/RoboclawEncoderSteps.h"
#include "motor_controller/position.h"
#include "std_msgs/String.h"
#include <sstream>
#include <iostream>
#include "geometry_msgs/Pose2D.h"

ros::Publisher inv_kinematics_publisher;
ros::Subscriber Done_Subscriber;
std::string DoneString;

void DoneCallback(const std_msgs::String::ConstPtr& message){
	DoneString=message->data;
}
std::vector<geometry_msgs::Pose2D> poses;
float squareLen=800;

int main(int argc, char **argv){
	geometry_msgs::Pose2D temp;
	temp.x=0;
	temp.y=0;
	temp.theta=0;
	poses.push_back(temp);
	temp.x=squareLen;
	poses.push_back(temp);
	temp.y=squareLen;
	poses.push_back(temp);
	temp.x=0;
	poses.push_back(temp);
	temp.y=0;
	poses.push_back(temp);


	ros::init(argc,argv,"square");
	ros::NodeHandle n;
	ros::Rate rate(10);
	int counter=0;
	inv_kinematics_publisher=n.advertise<geometry_msgs::Pose2D>("/inv_kinematics",10);
	Done_Subscriber=n.subscribe("/DoneTopic",100,&DoneCallback);
	for(int i=0;i<poses.size();i++){
		ROS_INFO_STREAM(poses[i]);
	}
	while(ros::ok()){
		ros::spinOnce();
		ROS_INFO_STREAM(poses[counter]);
		inv_kinematics_publisher.publish(poses.at(counter));
		ros::Duration(0.5).sleep();
		ros::spinOnce();
		
		if(DoneString=="Done"){
			ros::Duration(1.5).sleep();
			ROS_INFO_STREAM("Sleeping");
			counter++;
			if(counter>4){
				break;
			}
			
		}

	}

}
