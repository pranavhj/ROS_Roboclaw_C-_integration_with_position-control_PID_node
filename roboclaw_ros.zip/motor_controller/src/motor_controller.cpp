#include "ros/ros.h"
#include "roboclaw/RoboclawMotorVelocity.h"
#include "roboclaw/RoboclawEncoderSteps.h"
#include <sstream>
#include <iostream>
using namespace std;

ros::Publisher velocity_publisher;
ros::Subscriber pose_subscriber;

roboclaw::RoboclawEncoderSteps pose;

void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message);
void PIDcontroller(float goal);

int main(int argc, char **argv)
{ros::init(argc,argv,"motor_controller");
ros::NodeHandle n;
ros::Rate rate(10);
velocity_publisher=n.advertise<roboclaw::RoboclawMotorVelocity>("/motor_cmd_vel",10);
pose_subscriber=n.subscribe("/motor_enc",10,&poseCallback);



cout<<"Start"<<endl;
PIDcontroller(-800000);
cout<<"End"<<endl;

roboclaw::RoboclawMotorVelocity vel_msg;
vel_msg.index=0;
vel_msg.mot1_vel_sps=0;
velocity_publisher.publish(vel_msg);


ros::spinOnce();
//cout<<pose.mot1_enc_steps<<endl;

}


void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message){
	pose.index=pose_message->index;
	pose.mot1_enc_steps=pose_message->mot1_enc_steps;
	pose.mot2_enc_steps=pose_message->mot2_enc_steps;
	

}

void PIDcontroller(float goal)
{roboclaw::RoboclawMotorVelocity vel_msg_;
vel_msg_.index=0;
ros::Rate loop_rate(100);
while(abs(goal-float(pose.mot1_enc_steps))>10.0)
	{cout<<abs(goal-float(pose.mot1_enc_steps))<<endl;
	float e=goal-float(pose.mot1_enc_steps);
	//cout<<pose.mot1_enc_steps<<endl;
	vel_msg_.mot1_vel_sps=5*e;
	velocity_publisher.publish(vel_msg_);

	ros::spinOnce();
	//loop_rate.sleep();

	}
vel_msg_.mot1_vel_sps=0;
velocity_publisher.publish(vel_msg_);
cout<<"loop ended"<<endl;
}
