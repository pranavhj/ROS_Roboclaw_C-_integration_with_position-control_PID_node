#include "ros/ros.h"
#include "roboclaw/RoboclawMotorVelocity.h"
#include "roboclaw/RoboclawEncoderSteps.h"
#include "motor_controller/position.h"
#include <sstream>
#include <iostream>
using namespace std;
float Kp1=5,ki1=0.00001,kd1=0.0,prev_e1=0,max_speed=30000,total_error_1=0;

ros::Publisher velocity_publisher;
ros::Subscriber pose_subscriber;
ros::Subscriber position_subscriber;
roboclaw::RoboclawEncoderSteps pose;
motor_controller::position position;


void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message);
void positionCallback(const motor_controller::position::ConstPtr& position_message);
void PIDcontroller(float goal);

int main(int argc, char **argv)
{ros::init(argc,argv,"motor_controller");
ros::NodeHandle n;
ros::Rate rate(10);
velocity_publisher=n.advertise<roboclaw::RoboclawMotorVelocity>("/motor_cmd_vel",10);
pose_subscriber=n.subscribe("/motor_enc",10,&poseCallback);
position_subscriber=n.subscribe("/position",10,&positionCallback);
cout<<position.position_1<<endl;
while(ros::ok())
{//cout<<"Start"<<endl;
PIDcontroller(position.position_1);
//cout<<"End"<<endl;

roboclaw::RoboclawMotorVelocity vel_msg;
vel_msg.index=0;
vel_msg.mot1_vel_sps=0;
velocity_publisher.publish(vel_msg);


ros::spinOnce();}
//cout<<pose.mot1_enc_steps<<endl;

}


void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message){
	pose.index=pose_message->index;
	pose.mot1_enc_steps=pose_message->mot1_enc_steps;
	pose.mot2_enc_steps=pose_message->mot2_enc_steps;
	PIDcontroller(position.position_1);
	

}

void positionCallback(const motor_controller::position::ConstPtr& position_message){
	position.position_1=position_message->position_1;
	position.position_2=position_message->position_2;
	position.position_3=position_message->position_3;
	

}
void PIDcontroller(float goal)
{roboclaw::RoboclawMotorVelocity vel_msg_; 
vel_msg_.index=0;
while(abs(goal-float(pose.mot1_enc_steps))>10.0)
	{cout<<abs(goal-float(pose.mot1_enc_steps))<<endl;
	float e=goal-float(pose.mot1_enc_steps);
	
        int speed=Kp1*e+ki1*(total_error_1)+kd1*(e-prev_e1);
	if (e>max_speed)
		e=max_speed;
	else if(e<-max_speed)
		e=-max_speed;	
	vel_msg_.mot1_vel_sps=1*e;
	
	velocity_publisher.publish(vel_msg_);

	ros::spinOnce();
	//loop_rate.sleep();
	prev_e1=e;
	total_error_1=total_error_1+e;
	}
vel_msg_.mot1_vel_sps=0;
velocity_publisher.publish(vel_msg_);
cout<<"loop ended"<<endl;
}
