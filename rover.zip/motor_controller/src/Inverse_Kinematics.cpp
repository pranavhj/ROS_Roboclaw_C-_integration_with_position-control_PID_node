#include "ros/ros.h"
#include "roboclaw/RoboclawMotorVelocity.h"
#include "roboclaw/RoboclawEncoderSteps.h"
#include "motor_controller/position.h"
#include "geometry_msgs/Pose2D.h"
#include <sstream>
#include <iostream>
using namespace std;
geometry_msgs::Pose2D pose;
void pose2DCallback(const geometry_msgs::Pose2D::ConstPtr& pose_message);
float* matrixCalculation(float x, float y, float w);

float targets[3];
ros::Publisher inv_kinematics_publisher;
ros::Subscriber inv_kinematics_subscriber;
int main(int argc, char **argv)
{
    ros::init(argc,argv,"inv_kinematics");
   
    ros::NodeHandle n;
    ros::Rate rate(10);
    inv_kinematics_publisher=n.advertise<motor_controller::position>("/position",10);
    inv_kinematics_subscriber=n.subscribe("/inv_kinematics",10,&pose2DCallback);

    float x=pose.x;
    float y=pose.y;
    float w=pose.theta;
    float *targets=matrixCalculation(x,y,w);
    ros::spinOnce();
    motor_controller::position position;
    position.position_1=int(*(targets));
    position.position_2=int(*(targets+1));
    position.position_3=int(*(targets+2));

    while(ros::ok())
    {   float x=pose.x;
        float y=pose.y;
        float w=pose.theta;
        float *targets=matrixCalculation(x,y,w);

        motor_controller::position position;
        position.position_1=int(*(targets));
        position.position_2=int(*(targets+1));
        position.position_3=int(*(targets+2));
        inv_kinematics_publisher.publish(position);
        //cout<<"Published"<<endl;
        ros::spinOnce();
    }


}

float* matrixCalculation(float x, float y, float w)
{    float body_twist;
    float body_velocity_x;
    float body_velocity_y;
    float wheel_radius;
    float wheel_distance; //chassis radius
    float motor_angVel_1; //angular velocity
    float motor_angVel_2;
    float motor_angVel_3;
    body_twist = w;
    body_velocity_x = x;
    body_velocity_y = y;
    wheel_radius = 10.16; /*in cms*/
    wheel_distance = 30; /*in cms*/
    motor_angVel_1 = ((-1*wheel_distance*body_twist) + body_velocity_x)/wheel_radius;
    motor_angVel_2 = ((-1*wheel_distance*body_twist) - (0.5*body_velocity_x) - (0.866*body_velocity_y))/wheel_radius;
    motor_angVel_3 = ((-1*wheel_distance*body_twist) - (0.5*body_velocity_x) + (0.866*body_velocity_y))/wheel_radius;
    targets[0]=(motor_angVel_1);
    targets[1]=(motor_angVel_2);
    targets[2]=(motor_angVel_3);
    return &targets[0];    
}

void pose2DCallback(const geometry_msgs::Pose2D::ConstPtr& pose_message)
{   pose=*(pose_message);
//cout<<pose.x<<"   pose.x"<<endl;
}