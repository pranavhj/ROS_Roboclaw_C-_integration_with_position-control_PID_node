#include "ros/ros.h"

#include "roboclaw/RoboclawEncoderSteps.h"
#include <sstream>
#include <iostream>
using namespace std;


ros::Subscriber pose_subscriber;

roboclaw::RoboclawEncoderSteps pose;
int enc_1=0,enc_2=0;
void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message);



int main(int argc, char **argv)


{ros::init(argc,argv,"enc_steps");
ros::NodeHandle n;
pose_subscriber=n.subscribe("/motor_enc",1000,&poseCallback);


ros::spin();
}


void poseCallback(const roboclaw::RoboclawEncoderSteps::ConstPtr& pose_message){
	pose.index=pose_message->index;
	pose.mot1_enc_steps=pose_message->mot1_enc_steps;
	pose.mot2_enc_steps=pose_message->mot2_enc_steps;
	
	enc_1=pose_message->mot1_enc_steps;
	enc_2=pose_message->mot1_enc_steps;
	cout<<pose_message->mot1_enc_steps<<endl;

//pose=pose_message;
}

